from pathlib import Path
import os,sys,json,subprocess,re,shutil,datetime,hashlib
work=Path(__file__).resolve().parent
plan=json.loads((work/'chains.json').read_text())[sys.argv[1]]
wf=Path.home()/'skylark/wf';core=wf/'wf-core'
os.environ.update(WF_ALLOCATED='yes',WF_TASK_ROOT=os.environ.get('TMPDIR','/tmp'))
# Use the real Gaussian binary already loaded by the existing scheduler worker.
os.environ['PATH']=str(Path(os.environ['TACHYON_REAL_G16']).parent)+':'+os.environ['PATH']
os.chdir(str(work));state=work/(sys.argv[1]+'.status.json')
data={'job_id':os.environ['SLURM_JOB_ID'],'node':os.uname().nodename,'chain':sys.argv[1],'status':'running','completed':[]}
def save():
 data['checked_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 temp=state.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2));temp.replace(state)
def summary(stem):return json.loads(subprocess.check_output([str(core),'summary',stem+'.out'],universal_newlines=True))
def run(stem,kind):
 data['stage']=stem;save()
 r=subprocess.run(['bash',str(wf/'wf'),'--worker',str(work),stem,kind])
 if kind=='ts' and r.returncode==15:
  p=work/(stem+'.inp');t=p.read_text()
  assert '%oldchk=' in t
  backup=work/(stem+'.ts-drop-original.inp');assert not backup.exists()
  shutil.copy2(p,backup);shutil.copy2(stem+'.out',stem+'.ts-drop-original.out')
  # Exact one-time recovery Opt replacement from the installed wf.
  t,count=re.subn(r'\bopt\s*=\s*\([^)]*\)','opt=(ts,nofreeze,calcfc,noeigentest,maxstep=5,maxcycles=200)',t,flags=re.I)
  assert count==1;p.write_text(t)
  r=subprocess.run(['bash',str(wf/'wf'),'--worker',str(work),stem,kind])
 if r.returncode:raise RuntimeError('%s: worker exit %s'%(stem,r.returncode))
 s=summary(stem)
 if not s.get('normal') or s.get('scf') is None:raise RuntimeError(stem+': abnormal termination')
 if kind in ('opt','ts') and not s.get('opt_converged'):raise RuntimeError(stem+': optimization did not converge')
 if kind in ('ircfwd','ircrev') and not s.get('irc_complete'):raise RuntimeError(stem+': IRC incomplete')
 return s
try:
 for name,digest in plan['hashes'].items():
  assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,'Input changed after submission: '+name
 for stem,kind,gate in plan['stages']:
  s=run(stem,kind)
  if gate=='ts':
   if not(s.get('modes_complete') and s.get('frequencies') and s.get('imaginary_count')==1 and not s.get('methyl_rotation') and not s.get('methyl_ambiguous')):
    raise RuntimeError(stem+': TS frequency/mode gate failed')
  elif gate=='minimum':
   if not(s.get('frequencies') and s.get('imaginary_count')==0):
    # The installed wf repairs an IRC minimum once using its frequency chk.
    optstem=stem[:-5];p=work/(optstem+'.inp');backup=p.with_suffix('.pre-repair.inp');shutil.copy2(p,backup)
    template=(Path.home()/'skylark/script/input/template-optguess.txt').read_text()
    template=template.replace(' nosymm',' nosymm EmpiricalDispersion=GD3BJ',1)
    chk=Path.home()/'skylark/chk'
    p.write_text('%%oldchk=%s/%s.chk\n%%chk=%s/%s.chk\n%%nprocshared=16\n%%mem=24GB\n'%(chk,stem,chk,optstem)+template.rstrip()+'\n\n1 2\n\n')
    run(optstem,'opt');s=run(stem,'freq')
    if not(s.get('frequencies') and s.get('imaginary_count')==0):raise RuntimeError(stem+': minimum gate failed after wf-style repair')
  data['completed'].append({'stem':stem,'kind':kind,'scf':s.get('scf'),'imaginary_count':s.get('imaginary_count')});save()
 data['status']='map_complete_review_required' if plan.get('map') else 'completed';save()
except BaseException as e:
 data['status']='failed';data['reason']=str(e);save();raise
