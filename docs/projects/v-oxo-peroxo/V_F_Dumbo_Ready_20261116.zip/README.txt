현재 실행본: 덤보 input.sh 템플릿 사용. 초기 route에 tight/ultrafine 등 임의 추가 옵션 없음.
계산 위치: /gpfs/home/26c093r2/skylark/AfterPhD/NinthVanadium (본 폴더)
4개 실제 Job ID: 184564, 184566, 184568, 184570.
이전 준비 입력은 대체되었습니다. 실행 중인 작업의 입력을 수정하거나 중복 제출하지 마세요.
최소점 opt/freq/bb, TS 및 IRC의 단계별 gate는 동봉한 chains.json/run_chain.py 참조.
