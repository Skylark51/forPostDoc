V_F Dumbo prepared calculations, 2026-11-16
Prepared only; no sbatch submission.
F-B: recovered genuine fluoride dissociation TS (-68.8033 cm-1), separate bound/dissociated minima. Tighter optimization + ultrafine integration validates soft TS.
F-A: exploratory 2D V1-O67 approach / V1-F2 elongation scan (7 x 7 nominal grid), not a TS calculation. Select suitable saddle candidates only after inspecting the map.
Same composition: 69 atoms, +1/doublet, UB3LYP-D3BJ/def2SVP, CPCM acetonitrile; 16 cores / 24GB.
BB inputs use def2TZVPP and can run ONLY after normal completion and mode validation of their own parent.
TS acceptance: exactly one relevant imaginary frequency. If refined TS moves materially, repeat forward/reverse IRC before using a barrier. Endpoint minima: zero imaginary frequencies.
Do not start all jobs blindly. A-map is the priority for the unresolved coordination pathway; F-B refinements are validation of recovered work.
Original files and all source checkpoints are preserved; new inputs use explicit coordinates and fresh checkpoint names.
