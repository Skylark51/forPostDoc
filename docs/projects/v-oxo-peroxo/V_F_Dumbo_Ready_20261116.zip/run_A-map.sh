#!/bin/bash
set -euo pipefail
/apps/application/miniconda3/bin/python "$(dirname "${BASH_SOURCE[0]}")/run_chain.py" A-map
