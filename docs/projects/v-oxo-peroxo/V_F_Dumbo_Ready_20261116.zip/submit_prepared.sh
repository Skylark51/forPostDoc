#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
"$HOME/script/g16.sh" F-B-TS-refine-20261116.inp --dry-run
"$HOME/script/g16.sh" F-B-bound-refine-20261116.inp --dry-run
"$HOME/script/g16.sh" F-B-dissociated-refine-20261116.inp --dry-run
"$HOME/script/g16.sh" F-A-VO-VF-map-20261116.inp --dry-run
# Replace --dry-run only after choosing the calculation(s) to run.
