# 바로 시작할 계산 입력 묶음

첫 3개 작업은 2026-11-14 23:18 KST에 lion39 / lion51 / lion34에 제출했고 실행을 확인했습니다. 이 입력으로 중복 제출하지 마세요.
현재 상태: 첫 3개 진행중. 상태 확인 시각: 2026-11-14T14:23:42.717158+00:00 (UTC). 이후 작업은 Cl 결과를 보고 결정합니다.

서버 작업 디렉터리: /home/skylark/AfterPhD/NinthVanadium
새 이름은 기존 원본과 다릅니다. 입력에 기존 oldchk/readfc를 넣지 않은 최초 작업은 좌표로 시작합니다.
각 nrun 묶음에는 opt, opt-freq, opt-freq-bb 입력이 모두 있습니다. opt plain input은 wf로 실행하지 않습니다.
nrun은 시트 행을 먼저 확인합니다. 아래 sheetRow를 V 시트 A열에 추가한 후 호출합니다. wf scan도 별도 새 행으로 기록합니다.
명령의 lionNN은 제출 직전 실제 유휴 상태와 자원 허용을 확인한 노드로 치환합니다. 이 묶음은 노드 배정을 하지 않습니다.
입력 자원: CPU 0-15, 60GB. 해당 노드에 16 core/60GB를 쓸 수 있을 때만 그대로 사용합니다.
세부 source/좌표/입력 내용은 manifest와 HTML의 오늘 할 계산을 참조하세요.

## 계산별 명령과 시트 이름

Cl · H₂O₂ 접근 구간을 0.05 Å로 세분화
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Cl-opt-freq-forVOform-scan.out
선택: 2-VIV-TBDAP-O-Cl-opt-freq-forVOform-scan.out의 6번째 Optimization completed 직전 orientation. Gaussian scan step 번호와는 구분합니다.
시트 A열: 2-VCl-A-VO-fine-20261114-scan.inp
명령: /home/skylark/script/wf 2-VCl-A-VO-fine-20261114-scan.inp lion39

Cl · 기존 H₂O₂ adduct를 중간체 기준계로 저장
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Cl-opt-freq-forVOform-scan2-freq-ts-freq.out
선택: 2-VIV-TBDAP-O-Cl-opt-freq-forVOform-scan2-freq-ts-freq.out의 마지막 orientation. 파일명에 ts가 있지만 구조는 minimum 후보로 재사용합니다.
시트 A열: 2-VCl-adduct-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 2-VCl-adduct-20261114-opt.inp lion51

V4 · side-on peroxo 초기 구조 A 최적화
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Cl-opt.out
선택: 2-VIV-TBDAP-O-Cl-opt.out의 마지막 수렴 구조에서 Cl만 제거하고 O₂²⁻ 배위 부분을 구성한 새 초기 모델입니다. 기존 계산 결과 구조가 아닙니다.
시트 A열: 1-V4-peroxo-seedA-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 1-V4-peroxo-seedA-20261114-opt.inp lion34

Cl · H₂O₂ 없는 전구체에서 V–Cl 해리부터 계산
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Cl-opt.out
선택: 2-VIV-TBDAP-O-Cl-opt.out의 마지막 수렴 구조. H₂O₂ 없는 61원자 전구체입니다.
시트 A열: 2-VCl-B-Cl-loss-20261114-scan.inp
명령: /home/skylark/script/wf 2-VCl-B-Cl-loss-20261114-scan.inp lionNN

V4 · side-on peroxo 초기 구조 B 최적화
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Cl-opt.out
선택: 2-VIV-TBDAP-O-Cl-opt.out의 마지막 수렴 구조에서 Cl만 제거하고 O₂²⁻ 배위 부분을 구성한 새 초기 모델입니다. 기존 계산 결과 구조가 아닙니다.
시트 A열: 1-V4-peroxo-seedB-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 1-V4-peroxo-seedB-20261114-opt.inp lionNN

F · H₂O₂ 접근 구간을 0.05 Å로 세분화
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-F-opt-freq-forVOform-scan.out
선택: 2-VIV-TBDAP-O-F-opt-freq-forVOform-scan.out의 5번째 Optimization completed 직전 orientation. Gaussian scan step 번호와는 구분합니다.
시트 A열: 2-VF-A-VO-fine-20261114-scan.inp
명령: /home/skylark/script/wf 2-VF-A-VO-fine-20261114-scan.inp lionNN

Br · H₂O₂ 접근 구간을 0.05 Å로 세분화
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan.out
선택: 2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan.out의 6번째 Optimization completed 직전 orientation. Gaussian scan step 번호와는 구분합니다.
시트 A열: 2-VBr-A-VO-fine-20261114-scan.inp
명령: /home/skylark/script/wf 2-VBr-A-VO-fine-20261114-scan.inp lionNN

Br · 회전 모드 + 방향으로 내려가 배위 minimum 확보
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan2-freq-ts-freq.out
선택: 2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan2-freq-ts-freq.out의 −85.2498 cm⁻¹ normal mode 좌표와 Cartesian 변위 벡터.
시트 A열: 2-VBr-bound-mode-plus-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 2-VBr-bound-mode-plus-20261114-opt.inp lionNN

Br · 회전 모드 − 방향으로 내려가 배위 minimum 확보
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan2-freq-ts-freq.out
선택: 2-VIV-TBDAP-O-Br-opt-freq-forVOform-scan2-freq-ts-freq.out의 −85.2498 cm⁻¹ normal mode 좌표와 Cartesian 변위 벡터.
시트 A열: 2-VBr-bound-mode-minus-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 2-VBr-bound-mode-minus-20261114-opt.inp lionNN

F · H₂O₂가 떨어져 있는 접근복합체 기준계 저장
원본: /home/skylark/AfterPhD/NinthVanadium/2-VIV-TBDAP-O-F-opt-freq-forVOform-2-scan-freq-ts-freq.out
선택: 2-VIV-TBDAP-O-F-opt-freq-forVOform-2-scan-freq-ts-freq.out의 마지막 orientation. 파일명에 ts가 있지만 구조는 minimum 후보로 재사용합니다.
시트 A열: 2-VF-encounter-20261114-opt-freq.out
명령: /home/skylark/script/nrun.sh 2-VF-encounter-20261114-opt.inp lionNN
